<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mi proyecto</title>
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
  <h1>Bienvenido a mi sitio CodeIgniter</h1>
</body>
</html>
